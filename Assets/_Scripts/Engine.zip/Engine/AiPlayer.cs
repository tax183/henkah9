﻿public interface AiPlayer
{
    void MakeMove();
}
